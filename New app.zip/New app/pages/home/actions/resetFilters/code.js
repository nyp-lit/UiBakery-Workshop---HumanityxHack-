ui.select.setValue(null);
ui.input.setValue('');