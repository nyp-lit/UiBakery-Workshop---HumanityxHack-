return {
  part: {{ui.cardPart.value}},
  damage: {{ui.toggle.value}},
  scratches: {{ui.toggle2.value}},
  comment: {{ui.textArea.value}},
};